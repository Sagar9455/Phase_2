import os
import json
import shutil
import git


class GitHandler:

    def __init__(self, repo_path):

        self.repo_path = repo_path

        self.repo = git.Repo(repo_path)

        self.input_dir = os.path.join(
            repo_path,
            "input"
        )

        self.output_dir = os.path.join(
            repo_path,
            "output"
        )

        self.jobs_file = os.path.join(
            repo_path,
            "jobs",
            "jobs.json"
        )

    def pull_latest(self):

        origin = self.repo.remotes.origin

        origin.pull()

    def push_changes(
        self,
        message="Updated output files"
    ):

        self.repo.git.add(all=True)

        try:

            self.repo.index.commit(message)

        except:
            pass

        origin = self.repo.remotes.origin

        origin.push()

    def get_selected_testcase(self):

        with open(self.jobs_file, "r") as f:

            data = json.load(f)

        return data["selected_testcase"]

    def copy_selected_testcase(
        self,
        destination_folder
    ):

        testcase_name = self.get_selected_testcase()

        source_file = os.path.join(
            self.input_dir,
            testcase_name
        )

        destination_file = os.path.join(
            destination_folder,
            "testcase.txt"
        )

        shutil.copy(
            source_file,
            destination_file
        )

        return testcase_name

    def update_job_status(self, status):

        with open(self.jobs_file, "r") as f:

            data = json.load(f)

        data["status"] = status

        with open(self.jobs_file, "w") as f:

            json.dump(
                data,
                f,
                indent=4
            )

    def copy_outputs_to_git(
        self,
        source_output_dir
    ):

        destination = os.path.join(
            self.output_dir,
            "latest_run"
        )

        # Remove old outputs
        if os.path.exists(destination):

            shutil.rmtree(destination)

        shutil.copytree(
            source_output_dir,
            destination
        )

