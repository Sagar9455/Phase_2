
import json
import tkinter as tk
from tkinter import messagebox

CONFIG_FILE = "config.json"

def load_config():
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=2)

def update_config():
    try:
        config = load_config()
        can_data = config["uds"]["can"]

        can_data["channel"] = entry_channel.get()
        can_data["interface"] = entry_interface.get()
        can_data["bitrate"] = int(entry_bitrate.get())
        can_data["dbitrate"] = int(entry_dbitrate.get())
        can_data["tx_id"] = entry_tx_id.get()
        can_data["rx_id"] = entry_rx_id.get()
        can_data["is_extended"] = var_extended.get()
        can_data["can_fd"] = var_fd.get()

        save_config(config)
        messagebox.showinfo("Success", "Configuration updated successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))

config = load_config()
can_data = config["uds"]["can"]

root = tk.Tk()
root.title("CAN UDS Config Editor")

labels = [
    "Channel", "Interface", "Bitrate", "DBitrate", "TX ID", "RX ID",
]

entry_channel = tk.Entry(root)
entry_channel.insert(0, can_data["channel"])
entry_channel.grid(row=0, column=1)

entry_interface = tk.Entry(root)
entry_interface.insert(0, can_data["interface"])
entry_interface.grid(row=1, column=1)

entry_bitrate = tk.Entry(root)
entry_bitrate.insert(0, can_data["bitrate"])
entry_bitrate.grid(row=2, column=1)

entry_dbitrate = tk.Entry(root)
entry_dbitrate.insert(0, can_data["dbitrate"])
entry_dbitrate.grid(row=3, column=1)

entry_tx_id = tk.Entry(root)
entry_tx_id.insert(0, can_data["tx_id"])
entry_tx_id.grid(row=4, column=1)

entry_rx_id = tk.Entry(root)
entry_rx_id.insert(0, can_data["rx_id"])
entry_rx_id.grid(row=5, column=1)

var_extended = tk.BooleanVar(value=can_data["is_extended"])
check_extended = tk.Checkbutton(root, text="Is Extended", variable=var_extended)
check_extended.grid(row=6, columnspan=2)

var_fd = tk.BooleanVar(value=can_data["can_fd"])
check_fd = tk.Checkbutton(root, text="CAN FD", variable=var_fd)
check_fd.grid(row=7, columnspan=2)

tk.Button(root, text="Update Config", command=update_config).grid(row=8, columnspan=2, pady=10)

for i, label in enumerate(labels):
    tk.Label(root, text=label).grid(row=i, column=0)

root.mainloop()
