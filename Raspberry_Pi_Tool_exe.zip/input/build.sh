#!/bin/bash

set -e

echo "🚀 Starting Raspberry Pi build..."

# Go to project root
cd "$(dirname "$0")"

# Create venv
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install dependencies
pip install -r requirements.txt

# Install PyInstaller (safe)
pip install pyinstaller

# Clean old builds
rm -rf build dist *.spec

echo "📦 Building executable..."

pyinstaller app/main.py \
  --name my_app \
  --onefile \
  --clean \
  --collect-submodules drivers \
  --collect-submodules can \
  --collect-submodules udsoncan \
  --hidden-import=RPi.GPIO \
  --hidden-import=can.interfaces.socketcan

echo "✅ Build complete!"
echo "👉 Run using: ./dist/my_app"